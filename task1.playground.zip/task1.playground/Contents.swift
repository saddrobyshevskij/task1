import UIKit
var str = "Hello,playground"
var name1 = "Alex"
name1 = "Ivan"
var name2 = "Oleg"
name2 = "Jerj"
print(name1)
print("Alex")
print(name1 + "" + name2)
var colorBlue = "blue"
