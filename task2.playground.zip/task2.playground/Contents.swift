import UIKit

var peremennaya = 10
let constant = 22
var a1:Int = 10
var a2:Double = 2.5
var a3:Float = 2.6
var a4 = 55
var c = a1 + Int(a2)
let i = 5 + 5.5
typealias mytype = Int
var chislo:mytype = 10
var o = 111_123_654
var boolvalue = false

if boolvalue == true {
        print("Hello")
    }
else{
    print("hey")
    }
typealias mytype2 = Double
var variable2 = 5.67
var variable3 = 3  + Int(variable2)
